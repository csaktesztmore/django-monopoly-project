from django.urls import path

from .views import main, game, jatek_tabla


app_name = 'game'

urlpatterns = [
    path('', main, name='main'),
    path('<slug>/', game, name='game'),
    path('<slug>/jatek-tabla/', jatek_tabla, name='jatek_tabla'),
]