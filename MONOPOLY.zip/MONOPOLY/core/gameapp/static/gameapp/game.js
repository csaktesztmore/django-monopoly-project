


const gameslug = document.getElementById('slug').textContent.trim();
console.log(gameslug);
const submitbtn = document.getElementById('submit-btn');
const datainput = document.getElementById('data-input');

let user = document.getElementById('user').textContent.trim();
const placeholder = document.getElementById('game-placeholder');
const socket = new WebSocket(`ws://${window.location.host}/ws/${gameslug}/`);

const gametable = document.getElementById('game-table');
var currentPlayerCounter = 0;
console.log(socket)
let firstPlayerThrow = false;
let firstPlayer;
let infoholder;

var players;
var values;
var theGame;
var currentPlayer;
var firstPDATA;





function randomIntFromInterval(min, max) { 
  return Math.floor(Math.random() * (max - min + 1) + min)
}



socket.onclose = function(e){
  console.log(e);
 
}


socket.onmessage = function(e){
    console.log('Server says: ' + e.data);
    const {sender, message} = JSON.parse(e.data);
    console.log(sender);
    console.log(message);

    updateTable();  
    
    //placeholder.innerHTML += `<p>${sender}: ${message}</p>`
    
};
  
function updateIndex(){
  socket.send(JSON.stringify({
    'message': "currentPlayer",
    'sender': currentPlayerCounter
  }))

}



submitbtn.addEventListener('click', ()=>{
  firstPlayerThrow = true;
  
  
  currentPlayerCounter++;
    if (currentPlayerCounter > players.length - 1 ){
      currentPlayerCounter = 0;
    }
  
  updateIndex();

  const data = randomIntFromInterval(1, 6)
  datainput.value = data;
  socket.send(JSON.stringify({
    'message': data,
    'sender': user
  }))

  updateIndex();
})




const fetchJatekTablaData = async () => {
  const response = await fetch(window.location.href + 'jatek-tabla/');
  const data = await response.json();
  console.log(data);
  return data;
}
socket.onopen = function(e){
  console.log('Connection established');
  
 /* const gameSettings = async () => {
    const data = await fetchJatekTablaData();
    theGame = data.theGame;
  };
  gameSettings();
  console.log("a játék: " + theGame);*/
 
  socket.send(JSON.stringify({
    'message': 0,
    'sender': user
  }))
};



const make_table = async() => {
  const data = await fetchJatekTablaData();
  console.log(data);
  for (let index = 1; index < 30; index++) {
    cell = document.getElementById('cell' + index);
    cell.innerHTML = index
  }
  rajt = document.getElementById('rajt')
  rajt.innerHTML = "<p>rajt</p>";
  players = data.jatek_tabla_labels;
  values = data.jatek_tabla_data;
  firstPDATA = data.firstPlayer;
  theGame = data.theGame;
  var endCheck = JSON.parse(theGame)
  const endData = JSON.parse(theGame)
  if (endCheck["ended"] == false){
    console.log("a játék: " + theGame);

    gametable.innerHTML = '<div id = "table"></div>'
    infoholder = document.getElementById('table');
    console.log(players);
    console.log(values);
    rajt = document.getElementById('rajt')
    rajt.innerHTML = "<p>rajt</p>";
    var startedData = JSON.parse(theGame)
    players.forEach((player, index) => {
      
      var value = values[index];
      infoholder.innerHTML += `<p>${player}: ${value}</p>`;
      console.log(player, value)
      if (value > 29){
      /* socket.send(JSON.stringify({
          'message': -value,
          'sender': player
        })) */
        value = value - Math.floor(value / 29) * 29
      }
      
      
      if (value == 0){
        cell = document.getElementById('rajt');
      }
      else{
        cell = document.getElementById('cell' + value);
        console.log("cell" + value);
        //cell.innerHTML = " ";
        
      }
      cell.innerHTML += `<p>${player}</p>`;
      
      
      if (value == 29) {
        user = document.getElementById('user').textContent.trim();

        wincell = document.getElementById('cell29');
        wincell.style.backgroundColor = "red";
        const sleep = ms => new Promise(r => setTimeout(r, ms));
        sleep(15000)
        element = startedData["playerIndex"] - 1;
        if (element == -1){
          element = players.length -1;
        }
        socket.send(JSON.stringify({
          'message': "vege",
          'sender': players[element]
        }))
        return
      }
      
    });
    
    if (startedData["started"] == false){
      if (user == firstPDATA){
        mainsett = document.getElementById('mainsettings1');
        mainsett.innerHTML = '<button class = "btn btn-primary" id = "start-btn">Start</button>'
        const startbutton = document.getElementById('start-btn');
        startbutton.addEventListener('click', ()=>{
          console.log("startPressed");
          socket.send(JSON.stringify({
            'message': "startPressed",
            'sender': "system"
          }))
        
          startbutton.remove();
          currentPlayerCounter = 0;
          updateIndex();
          updateTable();
        })
      }
      else{
        
      }
      submitbtn.disabled = true;
    }
    else{

      currentPlayerCounter = startedData["playerIndex"];
      if (players.indexOf(user) == startedData["playerIndex"]){
        submitbtn.disabled = false;
        currentPlayer = players[startedData["playerIndex"]];
      
    
      }
      else{
        submitbtn.disabled = true;
      }
    currentPlayer = players[startedData["playerIndex"]];  
    cPlayerPlace = document.getElementById('currentPlayerField');
    cPlayerPlace.innerHTML = currentPlayer;
    console.log("jelenlegi ember:" + firstPlayer);
    console.log("jelenlegi index:" + currentPlayerCounter);
    }
  /*
    console.log(firstPDATA + " from data")

    if (currentPlayer == undefined && !firstPlayerThrow){
      player_index = players.indexOf(firstPDATA);
      currentPlayerCounter = player_index;
      currentPlayer = players[currentPlayerCounter];
      console.log("jelenlegi index from if:" + player_index);

    }
    else if(!firstPlayerThrow){
      player_index = players.indexOf(firstPDATA);
      currentPlayerCounter = player_index;
      console.log("jelenlegi index from elseif:" + player_index);
    }
    else{
      currentPlayerCounter++;
      if (currentPlayerCounter > players.length - 1 ){
        currentPlayerCounter = 0;
      }
      currentPlayer = players[currentPlayerCounter];
    }
    updateIndex();
    cPlayerPlace = document.getElementById('currentPlayerField');
    cPlayerPlace.innerHTML = currentPlayer;
    
    console.log("jelenlegi ember:" + firstPlayer);
    console.log("jelenlegi index:" + currentPlayerCounter);*/
    /*
    else{
      if (firstPlayerThrow)
      {
        currentPlayerCounter++;
      }
      
      currentPlayer = players[currentPlayerCounter];
      console.log("jelenlegi index from else:" + player_index);
    }
    
    
    currentPlayerCounter++;
    if (currentPlayerCounter > players.length - 1 ){
      currentPlayerCounter = 0;
    }
    if ((currentPlayer == NaN || currentPlayer == undefined ) && !firstPlayerThrow){
      currentPlayer = players[players.length - 1]
    }
    else{
      currentPlayer = players[currentPlayerCounter]
    }
    console.log("jelenlegi ember:" + currentPlayer);
    console.log("jelenlegi index:" + currentPlayerCounter + index);
    cPlayerPlace = document.getElementById('currentPlayerField');
    cPlayerPlace.innerHTML = currentPlayer;
    */
  }
  else{
    endscreen = document.getElementById('wholestuff');
    endscreen.innerHTML = ""

   
    endscreen.innerHTML += "<p>A nyertes: " + endData["winner"] + "</p>"
    
    
  }
}


const updateTable = async() => {
  if (infoholder){
    infoholder.remove();
  }
  await make_table();
}
make_table();
