from django.db import models
from django.utils.text import slugify
# Create your models here.
from django.urls import reverse
import json

class Game(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(blank=True)
    playerIndex = models.IntegerField(default=0)
    started = models.BooleanField(default=False)
    ended = models.BooleanField(default=False)
    firstUser = models.CharField(max_length=100, default="")  
    winner = models.CharField(blank=True, max_length=100)  


    def get_absolute_url(self):
        return reverse("gameapp:game", kwargs={"slug": self.slug})
    def toJSON(self):
        return json.dumps(self, default=lambda o: o.__dict__, 
            sort_keys=True, indent=4)

    @property
    def data(self):
        return self.player_set.all()
    
    def __str__(self):
        return self.name
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super(Game, self).save(*args, **kwargs)

class Player(models.Model):
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    value = models.IntegerField()
    owner = models.CharField(max_length=100)
    isLeader = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.owner}, {self.value}"