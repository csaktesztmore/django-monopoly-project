from django.urls import re_path as url
from .consumers import GameConsumer




websocket_urlpatterns = [
    url(r'^ws/(?P<game_slug>[^/]+)/$', GameConsumer.as_asgi()),
]