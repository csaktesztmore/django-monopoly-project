from django.shortcuts import render, redirect, get_object_or_404

from .models import Player, Game
# Create your views here.
from faker import Faker
from django.http import JsonResponse, HttpResponse
from django.db.models import Sum
import json
fake = Faker()

username = ""

def main(request):
    global username
    stats = Game.objects.all()
    if request.method == "POST":
        new_game = request.POST.get("new-game")
        username = request.POST.get("username")
        obj, _ = Game.objects.get_or_create(name=new_game)
        return redirect("gameapp:game", obj.slug)
    
    return render(request,'gameapp/main.html', {"stats": stats})


def game(request, slug):
    global username
    obj = get_object_or_404(Game, slug=slug)
    
    idg_help = username
    username = ""
    if obj.started == False:
        idg_help = request.user.username if request.user.username else fake.name() if idg_help == "" else idg_help
        if obj.firstUser == "":
            obj.firstUser = idg_help
            obj.save()
        return render(request, 'gameapp/game.html', {
            'name': obj.name,
            'slug': obj.slug,
            'data': obj.data,
            'user': idg_help,
            'firstuser': obj.firstUser,
        })
    else:
        if obj.ended == True:
            return HttpResponse(f"Game is already ended, the winner was: {obj.winner}")
        return HttpResponse("Game is already started")


def jatek_tabla(request, slug):
    obj = get_object_or_404(Game, slug=slug)
    qs = obj.data.values('owner').annotate(Sum('value'))
    jatek_tabla_data = [x["value__sum"] for x in qs]
    jatek_tabla_labels = [x["owner"] for x in qs]
    firstPlayer = obj.firstUser
    return JsonResponse({
        'theGame': obj.toJSON(), 
        "jatek_tabla_data": jatek_tabla_data,
        "jatek_tabla_labels": jatek_tabla_labels,
        "firstPlayer": firstPlayer
    })