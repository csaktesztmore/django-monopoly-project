from channels.generic.websocket import AsyncWebsocketConsumer
import json

from channels.db import database_sync_to_async
from .models import Game, Player


class GameConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        game_slug = self.scope['url_route']['kwargs']['game_slug']
        self.game_slug = game_slug
        self.room_group_name = f"game-{game_slug}"
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        await self.accept()

    async def disconnect(self, close_code):
        print(f"Disconnected: {close_code}")

        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )

    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        message = text_data_json['message']
        sender = text_data_json['sender']
        slug = self.game_slug 
        if message == "currentPlayer":

            await self.game_index_save(sender)
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                'type': 'refresh',
                'message': "refresh",
                'sender': "server"
                }
            )
           
        
        elif message == "startPressed":
            await self.game_started_save(True)
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                'type': 'refresh',
                'message': "refresh",
                'sender': "server"
                }
            )
        elif message == "vege":
            await self.game_ended_save(True, sender)
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                'type': 'refresh',
                'message': "refresh",
                'sender': "server"
                }
            )
        else:
            await self.save_data_item(message, sender, slug)
            print(f"Received message: {message}, sender: {sender}")

            await self.channel_layer.group_send(
                self.room_group_name,
                {
                'type': 'game_message',
                'message': message,
                'sender': sender
                }
            )

    
        
    async def game_message(self, event):
        message = event['message']
        sender = event['sender']
        
        await self.send(text_data=json.dumps({
            'message': message,
            'sender': sender    
            }))
        
    async def refresh(self, event):
        message = event['message']
        sender = event['sender']
        
        await self.send(text_data=json.dumps({
            'message': message,
            'sender': sender    
            }))
        
    @database_sync_to_async
    def create_data_item(self, message, sender, slug):
        obj = Game.objects.get(slug=slug)
        return Player.objects.create(game = obj, value = message, owner = sender)

    async def save_data_item(self, message, sender, slug):

        await self.create_data_item(message, sender, slug)

    @database_sync_to_async
    def game_index(self, value):
    
        slug = self.game_slug
        obj = Game.objects.get(slug=slug)   
        obj.playerIndex = value
        obj.save()

    async def game_index_save(self, value):
    
        await self.game_index(value)

    @database_sync_to_async
    def game_started(self, value):
    
        slug = self.game_slug
        obj = Game.objects.get(slug=slug)   
        obj.started = value
        obj.save()

    async def game_started_save(self, value):
        await self.game_started(value)

    @database_sync_to_async
    def game_ended(self, value, winner):
    
        slug = self.game_slug
        obj = Game.objects.get(slug=slug)   
        obj.ended = value
        obj.winner = winner
        obj.save()

    async def game_ended_save(self, value, winner):
        await self.game_ended(value, winner)

